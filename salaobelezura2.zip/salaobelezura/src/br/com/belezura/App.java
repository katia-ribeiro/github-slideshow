package br.com.belezura;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import br.com.belezura.entidades.AreaCorporal;
import br.com.belezura.entidades.Atendimento;
import br.com.belezura.entidades.Cliente;
import br.com.belezura.entidades.Funcionario;
import br.com.belezura.entidades.Servico;
import br.com.belezura.entidades.ServicoDesejado;
import br.com.belezura.negocio.Agendamento;

public class App {

	public static void main(String[] args) {

		Agendamento agendamento = new Agendamento();
		
		Cliente cliente = new Cliente("Jorge", "M", "", "");
		
		Servico servico3 = new Servico("corte masculino", "", AreaCorporal.CABELO, 45.0);
		
		List<Servico> servicos = new ArrayList<Servico>();
		servicos.add(servico3);
		
		agendamento.agendar(cliente, LocalDate.of(2021, 2, 10), servicos);
		
	}

}
