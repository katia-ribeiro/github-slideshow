package br.com.belezura.negocio;

import java.time.LocalDate;
import java.util.List;

import br.com.belezura.dados.FuncionarioDao;
import br.com.belezura.entidades.Atendimento;
import br.com.belezura.entidades.Cliente;
import br.com.belezura.entidades.Funcionario;
import br.com.belezura.entidades.Servico;
import br.com.belezura.entidades.ServicoDesejado;

public class Agendamento {
	
	public Atendimento agendar(Cliente cliente, LocalDate dataAtendimento, List<Servico> servicos) {
		
		Atendimento atendimento = new Atendimento(cliente, dataAtendimento);
		
		FuncionarioDao funcDao = new FuncionarioDao();
		
		List<Funcionario> funcionariosCadastrados = funcDao.listarTodos();
		
		// fazer o m�todo que consiga pegar um funcion�rio habilitado para cada servico que venha no
		// parametro servicos
		for (Servico servico : servicos) {
			for (Funcionario funcionario : funcionariosCadastrados) {
				if(verificaFuncHabilitado(funcionario, servico)) {
					
					ServicoDesejado servDesejado = new ServicoDesejado();
					servDesejado.setFuncionario(funcionario);
					servDesejado.setServico(servico);
					
					atendimento.addServicoDesejado(servDesejado);
					
					break;
				}
			}
		}
		
		return atendimento;
	}
	
	private boolean verificaFuncHabilitado(Funcionario func, Servico serv) {
		
		for (Servico servicoHabilitado : func.getServicosHabilitados()) {
			
			if(servicoHabilitado.getNome().equals(serv.getNome())) {
				
				return true;
			} 
		}
		
		return false;
		
	}

}
