package br.com.belezura.entidades;

import java.time.LocalTime;

public class ServicoDesejado {
	
	private Servico servico;
	private Funcionario funcionario;
	private LocalTime horarioInicio;
	private LocalTime horarioFim;
	
	public ServicoDesejado() {}
	
	public ServicoDesejado(Servico servico, Funcionario funcionario, LocalTime horarioInicio, LocalTime horarioFim) {
		this.servico = servico;
		this.funcionario = funcionario;
		this.horarioInicio = horarioInicio;
		this.horarioFim = horarioFim;
	}

	public Servico getServico() {
		return servico;
	}
	public void setServico(Servico servico) {
		this.servico = servico;
	}
	public Funcionario getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	public LocalTime getHorarioInicio() {
		return horarioInicio;
	}
	public void setHorarioInicio(LocalTime horarioInicio) {
		this.horarioInicio = horarioInicio;
	}
	public LocalTime getHorarioFim() {
		return horarioFim;
	}
	public void setHorarioFim(LocalTime horarioFim) {
		this.horarioFim = horarioFim;
	}
	
	

}
