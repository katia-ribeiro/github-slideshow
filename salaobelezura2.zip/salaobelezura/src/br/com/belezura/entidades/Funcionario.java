package br.com.belezura.entidades;

import java.util.ArrayList;
import java.util.List;

public class Funcionario {

	private String nome;
	private String sexo;
	private String endereco;
	private String telefone;
	private List<Servico> servicosHabilitados = new ArrayList<Servico>();
	
	public Funcionario() {}
	
	public Funcionario(String nome, String sexo, String endereco, String telefone) {
		this.nome = nome;
		this.sexo = sexo;
		this.endereco = endereco;
		this.telefone = telefone;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public List<Servico> getServicosHabilitados() {
		return servicosHabilitados;
	}
	public void addServicoHabilitado(Servico servico) {
		this.servicosHabilitados.add(servico);
	}
	
	
	
	
}
