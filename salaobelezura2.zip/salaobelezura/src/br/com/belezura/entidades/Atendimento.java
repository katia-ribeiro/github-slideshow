package br.com.belezura.entidades;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Atendimento {

	private Cliente cliente;
	private LocalDate data;
	private List<ServicoDesejado> servicosDesejados = new ArrayList<ServicoDesejado>();
	
	public Atendimento() {}
	
	public Atendimento(Cliente cliente, LocalDate data) {
		this.cliente = cliente;
		this.data = data;
	}

	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public LocalDate getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data = data;
	}
	public List<ServicoDesejado> getServicosDesejados() {
		return servicosDesejados;
	}
	public void addServicoDesejado(ServicoDesejado servicoDesejado) {
		this.servicosDesejados.add(servicoDesejado);
	}
	
}
