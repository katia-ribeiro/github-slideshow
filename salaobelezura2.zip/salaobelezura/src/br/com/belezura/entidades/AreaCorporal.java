package br.com.belezura.entidades;

public enum AreaCorporal {
	CABELO,
	MAOS,
	PES,
	ROSTO,
	CORPO
}
