package br.com.belezura.entidades;

public class Servico {

	private String nome;
	private String descricao;
	private AreaCorporal areaCorporal;
	private double valor;
	
	public Servico() {}
	
	
	public Servico(String nome, String descricao, AreaCorporal areaCorporal, double valor) {
		this.nome = nome;
		this.descricao = descricao;
		this.areaCorporal = areaCorporal;
		this.valor = valor;
	}
	


	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public AreaCorporal getAreaCorporal() {
		return areaCorporal;
	}
	public void setAreaCorporal(AreaCorporal areaCorporal) {
		this.areaCorporal = areaCorporal;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
}
