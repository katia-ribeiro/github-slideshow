package br.com.belezura.dados;

import java.util.ArrayList;
import java.util.List;

import br.com.belezura.entidades.AreaCorporal;
import br.com.belezura.entidades.Funcionario;
import br.com.belezura.entidades.Servico;

public class FuncionarioDao {

	public List<Funcionario> listarTodos() {
		
		List<Funcionario> funcionarios = new ArrayList<Funcionario>();
		
		Servico servico1 = new Servico("corte infantil", "", AreaCorporal.CABELO, 60.0);
		Servico servico2 = new Servico("corte feminino", "", AreaCorporal.CABELO, 100.0);
		Servico servico3 = new Servico("corte masculino", "", AreaCorporal.CABELO, 45.0);
		Servico servico4 = new Servico("hidratacao", "", AreaCorporal.CABELO, 80.0);
		
		
		Funcionario func1 = new Funcionario("Gustavo", "M", "", "");
		func1.addServicoHabilitado(servico3);
		
		Funcionario func2 = new Funcionario("Suzy", "F", "", "");
		func2.addServicoHabilitado(servico3);
		func2.addServicoHabilitado(servico2);
		
		Funcionario func3 = new Funcionario("Felizberta", "F", "", "");
		func3.addServicoHabilitado(servico1);
		func3.addServicoHabilitado(servico2);
		func3.addServicoHabilitado(servico4);
		
		funcionarios.add(func1);
		funcionarios.add(func2);
		funcionarios.add(func3);
		
		System.out.println("SELECT * FROM FUNCIONARIOS;");
		
		return funcionarios;
		
	}
}
